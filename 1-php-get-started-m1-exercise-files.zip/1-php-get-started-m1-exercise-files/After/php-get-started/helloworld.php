<!DOCTYPE html>
<html>
<head>
    <title>PHP</title>
</head>
<body>
<p><?php
    echo "Hello World!";
    ?></p>
</body>
</html>